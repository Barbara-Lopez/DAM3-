# Manual de usuario
- Una vez ejecutas el cliente te saldrá una ventana con un desplegable en el que seleccionaras el grupo en al que 
quieres unirte.
- Una vez te unes si no está en blanco, al clicar en el botón unirse te aparecerá otra ventana. En caso de que no 
ayas selecionado ninguna te aparecerá el desplegable en rojo.
- En la ventana siguiente en la parte de arriba tienes una casilla para poder poner el nombre y un desplegable en 
el que esta puesto el grupo al que teas unido.
- Si el apartado donde tienes que poner el nombre no lo cambias o está vacío se pondra en rojo(no se puede enviar nada 
hasta que se solucione) hasta que le pongas un nombre y envies el texto por primera vez una vez cambiado. Al apartado 
del nombre se le quitará el color rojo y no lo podrás modificar.
- Te encontrarás un hueco vacío en medio de la ventana. Es para poder recibir los mensajes que se envien desde el grupo al 
que te has unido.
- Luego esta donde tu escribes y abajo de el el botón de enviar. Una vez clicas en el si no hay nada no se envia y 
si hay algún problema con el nombre(los anteriores mencionados) tampoco.
- Si escribes _adios_ independientemente de si esta en mayusculas o minusculas saldras de la app del chat.

- El servidor solo hay que ejecutarlo para que se puedan conectar los clientes.
 