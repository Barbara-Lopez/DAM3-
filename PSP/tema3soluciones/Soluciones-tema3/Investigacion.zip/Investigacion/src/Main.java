import java.net.InetAddress;
import java.net.UnknownHostException;

public class Main {
    public static void main(String[] args) {

                try {
                    System.out.println("-> Direccion IP de una URL, por nombre ");
                    InetAddress address = InetAddress.getByName("www.egibide.org");
                    System.out.println(address);

                    System.out.println("-> Nombre a partir de la direccion");

                    System.out.println(address.getHostName());

                    System.out.println("-> Direccion IP actual de LocalHost");
                    address = InetAddress.getLocalHost();
                    System.out.println(address);
                    address= InetAddress.getByName("localhost");
                    System.out.println(address);


                    System.out.println("-> Nombre de LocalHost a partir de la direccion");

                    System.out.println(address.getHostName());

                    System.out.println("-> Metodo toString");

                    System.out.println(address.toString());

                    InetAddress[] direcciones = InetAddress.getAllByName("java.sun.com");
                    for (int i = 0; i < direcciones.length; i++) {
                        System.out.println(direcciones.length);
                        System.out.println("\t\t" + direcciones[i].toString());
                    }

                } catch (UnknownHostException e) {
                    System.out.println(e);
                    System.out.println("Debes estar conectado para que esto funcione bien.");
                }



            }
        }


