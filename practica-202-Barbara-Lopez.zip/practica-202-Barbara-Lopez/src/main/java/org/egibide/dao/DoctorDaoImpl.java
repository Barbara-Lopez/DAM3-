package org.egibide.dao;

import org.egibide.idao.DoctorDao;
import org.egibide.idao.DoctorRepository;
import org.egibide.models.Doctor;
import org.egibide.utils.DatabaseConnection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DoctorDaoImpl implements DoctorDao, DoctorRepository {

    @Override
    public int add(Doctor doctor) {
        String query = "INSERT INTO doctors (name, lastname,dni,salary,speciality) VALUES (?,?,?,?,?)";
        PreparedStatement ps;
        try {
            ps = DatabaseConnection.getInstance().getConnection().prepareStatement(query);
            ps.setString(1,doctor.getName());
            ps.setString(2,doctor.getLastname());
            ps.setString(3,doctor.getDni());
            ps.setDouble(4,doctor.getSalary());
            ps.setString(5,doctor.getSpeciality());

            int result = ps.executeUpdate();
            return result;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
        @Override
    public Boolean delete(int id) {
            String query = "delete from doctors where id=?";
            PreparedStatement ps;
            try {
                ps = DatabaseConnection.getInstance().getConnection().prepareStatement(query);
                ps.setInt(1, id);
                ps.execute();
                Boolean result = ps.execute();
                return result;
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
    }

    @Override
    public Doctor getDoctor(int id) {
        String query = "select * from doctors where id=?";
        PreparedStatement ps;

        Doctor doctor = null;

        try {
            ps = DatabaseConnection.getInstance().getConnection().prepareStatement(query);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                doctor = new Doctor(rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("lastname"),
                        rs.getString("dni"),
                        rs.getDouble("salary"),
                        rs.getString("speciality"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return doctor;
    }

    @Override
    public List<Doctor> getDoctors() {
        String query = "select * from doctors";
        PreparedStatement ps;

        List<Doctor> doctor = new ArrayList<>();

        try {
            ps = DatabaseConnection.getInstance().getConnection().prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                doctor.add(new Doctor(rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("lastname"),
                        rs.getString("dni"),
                        rs.getDouble("salary"),
                        rs.getString("speciality")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return doctor;
    }
    @Override
    public boolean update(Doctor doctor) {
        if (doctorExists(doctor.getId())) {
            String query = "update doctors set name=?, lastname=?, dni=?, salary=?, speciality=? where id=?";
            PreparedStatement ps;
            int rs = 0;

            try {
                ps = DatabaseConnection.getInstance().getConnection().prepareStatement(query);
                ps.setString(1,doctor.getName());
                ps.setString(2,doctor.getLastname());
                ps.setString(3,doctor.getDni());
                ps.setDouble(4,doctor.getSalary());
                ps.setString(5,doctor.getSpeciality());
                ps.setInt(6, doctor.getId());

                rs = ps.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return (rs > 0);
        }
        return false;
    }

    private boolean doctorExists(int id) {
        String query = "select * from doctors where id=?";
        PreparedStatement ps;

        ResultSet doctor;

        try {
            ps = DatabaseConnection.getInstance().getConnection().prepareStatement(query);
            ps.setInt(1, id);
            doctor = ps.executeQuery();

            return doctor.next();


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public boolean isPatientAttendedByDoctor(int patient_id, int doctor_id){
        String query = "select * from Patient where id=? and doctor=?";
        PreparedStatement ps;

        ResultSet doctor;

        try {
            ps = DatabaseConnection.getInstance().getConnection().prepareStatement(query);
            ps.setInt(1, patient_id);
            ps.setInt(2, doctor_id);
            doctor = ps.executeQuery();
            return doctor.next();


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
