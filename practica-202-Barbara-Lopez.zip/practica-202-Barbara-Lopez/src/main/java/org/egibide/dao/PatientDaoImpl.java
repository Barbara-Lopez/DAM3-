package org.egibide.dao;

import org.egibide.idao.PatientDao;
import org.egibide.models.Patient;
import org.egibide.utils.DatabaseConnection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PatientDaoImpl implements PatientDao {
    @Override
    public int add(Patient patient) {
        String query = "INSERT INTO Patient (name, lastname,dni,age,phone,disease,doctor) VALUES (?,?,?,?,?,?,?)";
        PreparedStatement ps;
        try {
            ps = DatabaseConnection.getInstance().getConnection().prepareStatement(query);
            ps.setString(1,patient.getName());
            ps.setString(2,patient.getLastname());
            ps.setString(3,patient.getDni());
            ps.setInt(4,patient.getAge());
            ps.setString(5,patient.getPhone());
            ps.setString(6,patient.getDisease());
            ps.setInt(7,patient.getDoctor());

            int result = ps.executeUpdate();
            return result;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Boolean delete(int id) {
        String query = "delete from Patient where id=?";
        PreparedStatement ps;
        try {
            ps = DatabaseConnection.getInstance().getConnection().prepareStatement(query);
            ps.setInt(1, id);
            ps.execute();
            Boolean result = ps.execute();
            return result;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Patient getPatient(int id) {
        String query = "select * from Patient where id=?";
        PreparedStatement ps;

        Patient patient = null;

        try {
            ps = DatabaseConnection.getInstance().getConnection().prepareStatement(query);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                patient = new Patient(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("lastname"),
                        rs.getString("dni"),
                        rs.getInt("age"),
                        rs.getString("phone"),
                        rs.getString("disease"),
                        rs.getInt("doctor"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return patient;
    }

    @Override
    public List<Patient> getPatients() {
        String query = "select * from Patient";
        PreparedStatement ps;

        List<Patient> patient= new ArrayList<Patient>();

        try {
            ps = DatabaseConnection.getInstance().getConnection().prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                patient.add(new Patient(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("lastname"),
                        rs.getString("dni"),
                        rs.getInt("age"),
                        rs.getString("phone"),
                        rs.getString("disease"),
                        rs.getInt("doctor")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return patient;
    }

    @Override
    public boolean update(Patient patient) {
        if (patientExists(patient.getId())) {
            String query = "update Patient set name=?, lastname=?, dni=?, age=?,phone=?, disease=?, doctor=? where id=?";
            PreparedStatement ps;
            int rs = 0;

            try {
                ps = DatabaseConnection.getInstance().getConnection().prepareStatement(query);
                ps.setString(1,patient.getName());
                ps.setString(2,patient.getLastname());
                ps.setString(3,patient.getDni());
                ps.setInt(4,patient.getAge());
                ps.setString(5,patient.getPhone());
                ps.setString(6,patient.getDisease());
                ps.setInt(7,patient.getDoctor());
                ps.setInt(8, patient.getId());

                rs = ps.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return (rs > 0);
        }
        return false;
    }
    private boolean patientExists(int id) {
        String query = "select * from Patient where id=?";
        PreparedStatement ps;

        ResultSet patient;

        try {
            ps = DatabaseConnection.getInstance().getConnection().prepareStatement(query);
            ps.setInt(1, id);
            patient = ps.executeQuery();

            return patient.next();


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public List<Patient> getPatientsByDoctorId(int doctor_id){
        String query = "select * from Patient where doctor=?";
        PreparedStatement ps;

        List<Patient> patient= new ArrayList<Patient>();

        try {
            ps = DatabaseConnection.getInstance().getConnection().prepareStatement(query);
            ps.setInt(1, doctor_id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                patient.add(new Patient(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("lastname"),
                        rs.getString("dni"),
                        rs.getInt("age"),
                        rs.getString("phone"),
                        rs.getString("disease"),
                        rs.getInt("doctor")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return patient;
    }
}
