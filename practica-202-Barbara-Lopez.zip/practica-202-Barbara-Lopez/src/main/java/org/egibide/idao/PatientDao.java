package org.egibide.idao;


import org.egibide.models.Patient;

import java.util.List;

public interface PatientDao {
    int add(Patient patient);
    Boolean delete(int id);
    Patient getPatient(int id);

    List<Patient> getPatients();

    boolean update(Patient patient);
    List<Patient> getPatientsByDoctorId(int doctor_id);
}
