package org.egibide.idao;

import org.egibide.models.Doctor;

public interface DoctorRepository {
    Doctor getDoctor(int doctor_id);
    boolean isPatientAttendedByDoctor(int patient_id, int doctor_id);
}
