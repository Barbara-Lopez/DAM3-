package org.egibide.idao;

import org.egibide.models.Doctor;

import java.util.List;

public interface DoctorDao {
    int add(Doctor doctor);
    Boolean delete(int id);
    Doctor getDoctor(int id);
    List<Doctor> getDoctors();
    boolean update(Doctor doctor);
}
