package org.egibide.models;


    public class Patient {


        private int id;
        private String name;
        private String lastname;
        private String dni;
        private int age;
        private String phone;
        private String disease;

        private int doctor;



// Constructors, getters, setters and toString

        public Patient(int id, String name, String lastname, String dni, int age, String phone, String disease, int doctor) {
            this.id = id;
            this.name = name;
            this.lastname = lastname;
            this.dni = dni;
            this.age = age;
            this.phone = phone;
            this.disease = disease;
            this.doctor = doctor;
        }



        public Patient(String name, String lastname, String dni, int age, String phone, String disease, int doctor) {
            this.name = name;
            this.lastname = lastname;
            this.dni = dni;
            this.age = age;
            this.phone = phone;
            this.disease = disease;
            this.doctor = doctor;
        }
        public void setDoctor(int doctor) {
            this.doctor = doctor;
        }

        public int getDoctor() {
            return doctor;
        }
        public int getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public String getLastname() {
            return lastname;
        }

        public String getDni() {
            return dni;
        }

        public int getAge() {
            return age;
        }

        public String getPhone() {
            return phone;
        }

        public String getDisease() {
            return disease;
        }
        public void setId(int id) {
            this.id = id;
        }

        public void setName(String name) {
            this.name = name;
        }

        public void setLastname(String lastname) {
            this.lastname = lastname;
        }

        public void setDni(String dni) {
            this.dni = dni;
        }

        public void setAge(int age) {
            this.age = age;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }

        public void setDisease(String disease) {
            this.disease = disease;
    }
        @Override
        public String toString() {
            return " Patient{" +
                    ", name='" + name + '\'' +
                    ", lastname='" + lastname + '\'' +
                    ", dni='" + dni + '\'' +
                    ", age=" + age +
                    ", phone='" + phone + '\'' +
                    ", disease='" + disease + '\'' +
                    ", doctor=" + doctor +
                    '}';
        }
}


