package org.egibide;

import org.egibide.dao.DoctorDaoImpl;
import org.egibide.dao.PatientDaoImpl;
import org.egibide.idao.DoctorDao;
import org.egibide.idao.DoctorRepository;
import org.egibide.idao.PatientDao;
import org.egibide.models.Doctor;
import org.egibide.models.Patient;
import org.egibide.utils.DatabaseConnection;

import java.sql.*;
import java.util.List;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        Connection con = null;

        DoctorDao dd = new DoctorDaoImpl();
        PatientDao pp = new PatientDaoImpl();

        try {
            con = DatabaseConnection.getInstance().getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        /*Doctor doctor = dd.getDoctor(1);

        System.out.println(doctor);

        doctor.setSpeciality("Digestivo");

        dd.update(doctor);

        System.out.println(dd.getDoctor(1));

        List<Doctor> doctores = dd.getDoctors();

        System.out.println("Listar los doctores:");

        for (int i = 0; i < doctores.size(); i++) {
            System.out.println(doctores.get(i).toString());
        }

        int hecho = dd.add(new Doctor(0, "barbara","lopez","19212351E",1520.02,"ojos"));
        if (hecho==1 ){
            System.out.println("Nuevo doctor añadido");
        }else{
            System.out.println("Problemas al añadir nuevo doctor");
        }
        Boolean delete = dd.delete(1);
        if (delete){
            System.out.println("Problemas al eliminar doctor con el id 1 ");
        }else{
            System.out.println("EL doctor con el id 1 eliminado");
        }
        doctores = dd.getDoctors();

        System.out.println("Listar los doctores:");

        for (int i = 0; i < doctores.size(); i++) {
            System.out.println(doctores.get(i).toString());
        }*/
        Patient patient =pp.getPatient(1);

        System.out.println(patient);

        patient.setDisease("dolor de cabeza");

        pp.update(patient);

        System.out.println(pp.getPatient(1));

        List<Patient> patients = pp.getPatients();

        System.out.println("Listar los pacientes:");

        for (int i = 0; i < patients.size(); i++) {
            System.out.println(patients.get(i).toString());
        }

        int hecho =pp.add(new Patient("pablo","sanchez","19215621E",12,"123456789","dolor estomacal",1));
        if (hecho==1 ){
            System.out.println("Nuevo paciente añadido");
        }else{
            System.out.println("Problemas al añadir nuevo paciente");
        }
        Boolean delete = pp.delete(1);
        if (delete){
            System.out.println("Problemas al eliminar paciente con el id 1 ");
        }else{
            System.out.println("EL doctor con el id 1 eliminado");
        }
        patients = pp.getPatients();

        System.out.println("Listar los pacientes:");

        for (int i = 0; i < patients.size(); i++) {
            System.out.println(patients.get(i).toString());
        }
/*
        DoctorRepository d = new DoctorDaoImpl();
        Doctor doctor2=d.getDoctor(3);
        int id=0;
        if (doctor2!=null){
            id=doctor2.getId();
            PatientDao p=new PatientDaoImpl();
            List<Patient> ps=p.getPatientsByDoctorId(id);
            doctor2.setAttendedPatients(ps);
            System.out.println(doctor2.toStringConPacientes());
            Boolean patientDoctorExiste= d.isPatientAttendedByDoctor(5, doctor2.getId());
            if(patientDoctorExiste){
                System.out.println("El paciente 5 es atendido por el doctor "+doctor2.getId());
            }else{
                System.out.println("El doctor numero "+doctor2.getId()+"no atiende al paciente 5 ");
            }
        }*/


        try {
            if (con != null) {
                con.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
