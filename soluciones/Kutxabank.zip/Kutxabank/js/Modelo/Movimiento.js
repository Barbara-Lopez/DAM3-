class Movimiento{
    constructor(importe,fecha,tipo)
    {
        this.importe = importe;
        this.fecha = fecha;
        this.tipo = tipo;
    }
}